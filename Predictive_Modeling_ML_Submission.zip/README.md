# Predictive Modeling Using Machine Learning

## Objective
Build supervised machine-learning models to predict customer churn and compare their performance.

## Dataset
A reproducible synthetic customer dataset contains 600 records with five predictor variables:
Age, Annual Income, Tenure Years, Monthly Usage Hours, and Support Calls. The target is Churn (0 = No, 1 = Yes).

## Preprocessing
Missing numeric values were filled with median values. The data was split 75/25 using stratification and a fixed random seed.

## Models
- Logistic Regression
- Decision Tree
- Random Forest

## Evaluation
Accuracy, Precision, Recall, F1-score, and ROC-AUC were calculated on the held-out test set.

## Best Model
**Random Forest**
- Accuracy: 0.640
- Precision: 0.647
- Recall: 0.595
- F1-score: 0.620
- ROC-AUC: 0.740

## Conclusion
The workflow demonstrates data preparation, supervised model training, model comparison, confusion-matrix analysis, ROC analysis, and feature-importance interpretation.
